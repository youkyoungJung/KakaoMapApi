package ddwucom.contest.centerpick.activity;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;

import net.daum.mf.map.api.MapCircle;
import net.daum.mf.map.api.MapPOIItem;
import net.daum.mf.map.api.MapPoint;
import net.daum.mf.map.api.MapReverseGeoCoder;
import net.daum.mf.map.api.MapView;
import android.Manifest;
import android.location.LocationManager;
import android.content.DialogInterface;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.odsay.odsayandroidsdk.API;
import com.odsay.odsayandroidsdk.ODsayData;
import com.odsay.odsayandroidsdk.ODsayService;
import com.odsay.odsayandroidsdk.OnResultCallbackListener;

import ddwucom.contest.centerpick.model.category_search.CategoryResult;
import ddwucom.contest.centerpick.model.category_search.Document;
import ddwucom.contest.centerpick.R;
import ddwucom.contest.centerpick.adapter.LocationAdapter;
import ddwucom.contest.centerpick.api.ApiClient;

import org.jetbrains.annotations.NotNull;
import org.json.JSONObject;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import ddwucom.contest.centerpick.api.ApiInterface;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.view.View.GONE;

public class MainActivity extends AppCompatActivity implements MapView.CurrentLocationEventListener,
        MapReverseGeoCoder.ReverseGeoCodingResultListener, MapView.MapViewEventListener, MapView.POIItemEventListener,
        MapView.OpenAPIKeyAuthenticationResultListener, View.OnClickListener {
    final static String TAG = "MapTAG";
    private MapView mapView;

    private ODsayService odsayService;

    private static final int GPS_ENABLE_REQUEST_CODE = 2001;
    private static final int PERMISSIONS_REQUEST_CODE = 100;
    public static MapPOIItem.CalloutBalloonButtonType MainButton;


    final int REQ_CODE = 100;
    String[] REQUIRED_PERMISSIONS = {Manifest.permission.ACCESS_FINE_LOCATION};


    public static ArrayList<String> latitude = new ArrayList<>(); //위도 담을 배열 리스트
    public static ArrayList<String> longitude = new ArrayList<>(); //경도 담을 배열 리스트

    public static double touch_x; //터치 위도 ->timeActivity
    public static double touch_y; //터치 경도 ->timeActivity

    //Double형 위경도
    ArrayList<Double> lat = new ArrayList<>();
    ArrayList<Double> lon = new ArrayList<>();

    public static ArrayList<String> pick_addressList = new ArrayList<>(); //출발 주소 저장

    public static String pick_address; //선택한 주소

    RecyclerView recyclerView;
    EditText mSearchEdit;
    ArrayList<Document> documentArrayList = new ArrayList<>(); //지역명 검색 결과 리스트

    static String center_pick = null;

    //유경's turn
    private FloatingActionButton fab, fab1, fab2, fab3, searchDetailFab, stopTrackingFab;
    private double mCurrentLng; //Long = X, Lat = Yㅌ
    private double mCurrentLat;
    private double mSearchLng = -1;
    private double mSearchLat = -1;
    private String mSearchName;
    boolean isTrackingMode = false; //트래킹 모드인지 (3번째 버튼 현재위치 추적 눌렀을 경우 true되고 stop 버튼 누르면 false로 된다)
    private Animation fab_open, fab_close;
    private Boolean isFabOpen = false;

    MapPOIItem searchMarker = new MapPOIItem();

    ArrayList<Document> bigMartList = new ArrayList<>(); //대형마트 MT1
    ArrayList<Document> gs24List = new ArrayList<>(); //편의점 CS2
    ArrayList<Document> subwayList = new ArrayList<>(); //지하철 SW8
    ArrayList<Document> bankList = new ArrayList<>(); //은행 BK9
    ArrayList<Document> cafeList = new ArrayList<>(); //카페
    ArrayList<Document> restaurantList = new ArrayList<>(); //음식점 FD6

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Context context = null;

//       getHashKey();

//        MapView mapView = new MapView(this);

//        RelativeLayout container = (RelativeLayout) findViewById(R.id.map_view);
//        container.addView(mapView);

        mapView = (MapView)findViewById(R.id.map_view);
        mapView.setCurrentLocationEventListener(this);

        if (!checkLocationServicesStatus()) {
            showDialogForLocationServiceSetting();
        }else {
            checkRunTimePermission();
        }
//버튼 설정
        initView();
        //       search();

    }

    private void initView() {
//        mapView = (MapView)findViewById(R.id.map_view);
//        mapView.setCurrentLocationEventListener(this);
//
//        if (!checkLocationServicesStatus()) {
//            showDialogForLocationServiceSetting();
//        }else {
//            checkRunTimePermission();
//        }

        fab_open = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fab_open);
        fab_close = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fab_close);
        fab = findViewById(R.id.fab);
        fab1 = findViewById(R.id.fab1);
        fab2 = findViewById(R.id.fab2);
        fab3 = findViewById(R.id.fab3);
//       // searchDetailFab = findViewById(R.id.fab_detail);
//       // stopTrackingFab = findViewById(R.id.fab_stop_tracking);
//
//        //버튼리스너
        fab.setOnClickListener(this);
        fab1.setOnClickListener(this);
        fab2.setOnClickListener(this);
        fab3.setOnClickListener(this);
//        searchDetailFab.setOnClickListener(this);
//        stopTrackingFab.setOnClickListener(this);
    }
    //    private void search(){
//        mSearchEdit = findViewById(R.id.searchText);
//        recyclerView = findViewById(R.id.map_recyclerview);
//        recyclerView.addItemDecoration(new DividerItemDecoration(getApplicationContext(), DividerItemDecoration.VERTICAL)); //아래구분선 세팅
//        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false); //레이아웃매니저 생
//        final LocationAdapter locationAdapter = new LocationAdapter(documentArrayList, getApplicationContext(), mSearchEdit, recyclerView);
//        recyclerView.setLayoutManager(layoutManager);
//        recyclerView.setAdapter(locationAdapter);
//
//        //검색기능
//        mSearchEdit.addTextChangedListener(new TextWatcher() {
//            @Override
//            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {
//                // 입력하기 전에
//                recyclerView.setVisibility(View.VISIBLE);
//                Log.d(TAG, "입력 전 상태");
//            }
//
//            @Override
//            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
//                if (charSequence.length() >= 1) {
//                    // if (SystemClock.elapsedRealtime() - mLastClickTime < 500) {
//                    Log.d(TAG, "검색창 바뀜");
//
//                    documentArrayList.clear();
//                    locationAdapter.clear();
//                    locationAdapter.notifyDataSetChanged();
//                    ApiInterface apiInterface = ApiClient.getApiClient().create(ApiInterface.class);
//                    Call<CategoryResult> call = apiInterface.getSearchLocation("KakaoAK a58f90fdd5bc2bfbd6f8658473a829aa", charSequence.toString(), 15);
//                    call.enqueue(new Callback<CategoryResult>() {
//                        @Override
//                        public void onResponse(@NotNull Call<CategoryResult> call, @NotNull Response<CategoryResult> response) {
//                            if (response.isSuccessful()) {
//                                assert response.body() != null;
//                                for (Document document : response.body().getDocuments()) {
//                                    locationAdapter.addItem(document);
//                                }
//                                locationAdapter.notifyDataSetChanged();
//                            }
//                            recyclerView.setVisibility(View.VISIBLE);
//                        }
//
//                        @Override
//                        public void onFailure(@NotNull Call<CategoryResult> call, @NotNull Throwable t) {
//                            Log.d(TAG, "입력 실패");
//                        }
//                    });
//                    //}
//                    //mLastClickTime = SystemClock.elapsedRealtime();
//                } else {
//                    if (charSequence.length() <= 0) {
//                        recyclerView.setVisibility(View.GONE);
//                    }
//                }
//            }
//
//            @Override
//            public void afterTextChanged(Editable editable) {
//                // 입력이 끝났을 때
//
//                Log.d(TAG, "입력 끝");
//            }
//        });
//
//        mSearchEdit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
//            @Override
//            public void onFocusChange(View view, boolean hasFocus) {
//                if (hasFocus) {
//                } else {
//                    recyclerView.setVisibility(View.GONE);
//                }
//            }
//        });
//        mSearchEdit.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Toast.makeText(getApplicationContext(), "검색리스트에서 장소를 선택해주세요", Toast.LENGTH_SHORT).show();
//            }
//        });
//
//
//
//    }
    protected void onDestroy(){
        super.onDestroy();
        mapView.setCurrentLocationTrackingMode(MapView.CurrentLocationTrackingMode.TrackingModeOnWithoutHeading);
        mapView.setShowCurrentLocationMarker(false);
    }

//    private void getHashKey(){    //해쉬키 구함
//        PackageInfo packageInfo = null;
//        try {
//            packageInfo = getPackageManager().getPackageInfo(getPackageName(), PackageManager.GET_SIGNATURES);
//        } catch (PackageManager.NameNotFoundException e) {
//            e.printStackTrace();
//        }
//        if (packageInfo == null)
//            Log.e("KeyHash", "KeyHash:null");
//
//        for (Signature signature : packageInfo.signatures) {
//            try {
//                MessageDigest md = MessageDigest.getInstance("SHA");
//                md.update(signature.toByteArray());
//                Log.d("KeyHash", Base64.encodeToString(md.digest(), Base64.DEFAULT));
//            } catch (NoSuchAlgorithmException e) {
//                Log.e("KeyHash", "Unable to get MessageDigest. signature=" + signature, e);
//            }
//        }
//    }


    @Override
    public void onReverseGeoCoderFoundAddress(MapReverseGeoCoder mapReverseGeoCoder, String s) {
        mapReverseGeoCoder.toString();

    }

    @Override
    public void onReverseGeoCoderFailedToFindAddress(MapReverseGeoCoder mapReverseGeoCoder) {

    }

    @Override
    public void onCurrentLocationUpdate(MapView mapView, MapPoint mapPoint, float v) {
        MapPoint.GeoCoordinate mapPointGeo = mapPoint.getMapPointGeoCoord();
    }

    @Override
    public void onCurrentLocationDeviceHeadingUpdate(MapView mapView, float v) {

    }

    @Override
    public void onCurrentLocationUpdateFailed(MapView mapView) {

    }

    @Override
    public void onCurrentLocationUpdateCancelled(MapView mapView) {

    }

    /*
    ActivityCompat.requestPermissions 사용한 퍼미션 요청의 결과 리턴받는 메소드
     */

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == PERMISSIONS_REQUEST_CODE && grantResults.length == REQUIRED_PERMISSIONS.length){
            //요청 코드가 PERMISSIONS_REQUEST_CODE 이고, 요청한 퍼미션 개수만큼 수신

            boolean check_result = true;

            //모든 퍼미션 허용했는지 체크
            for (int result : grantResults){
                if (result != PackageManager.PERMISSION_GRANTED){
                    check_result = false;
                    break;
                }
            }

            if (check_result){
                mapView.setCurrentLocationTrackingMode(MapView.CurrentLocationTrackingMode.TrackingModeOnWithoutHeading);
            }
            else{
                if (ActivityCompat.shouldShowRequestPermissionRationale(this, REQUIRED_PERMISSIONS[0])){
                    Toast.makeText(MainActivity.this, "퍼미션이 거부되었습니다. 앱을 다시 실행하여 퍼미션을 허용해주세요.",
                            Toast.LENGTH_LONG).show();
                    finish();
                }
                else{
                    Toast.makeText(MainActivity.this, "퍼미션이 거부되었습니다. 설정(앱 정보)에서 퍼미션을 허용해야 합니다.",
                            Toast.LENGTH_LONG).show();
                }
            }
        }
    }
    void checkRunTimePermission(){
        //런타임 퍼미션 처리

        //1. 위치 퍼미션 가지고 있는지 체크
        int hasFindLocationPermission = ContextCompat.checkSelfPermission(MainActivity.this,
                Manifest.permission.ACCESS_FINE_LOCATION);

        if (hasFindLocationPermission == PackageManager.PERMISSION_GRANTED){
            //이미 퍼미션을 가지고 있다면

            //위치 값 가져오기 가능
            mapView.setCurrentLocationTrackingMode(MapView.CurrentLocationTrackingMode.TrackingModeOnWithoutHeading);
        }
        else{
            //퍼미션 요청 허용한 적 없다면 퍼미션 요청 필요

            //거부한 적 있는 경우
            if (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this, REQUIRED_PERMISSIONS[0])){
                Toast.makeText(MainActivity.this, "이 앱을 실행하려면 위치 접근 권한이 필요합니다.",
                        Toast.LENGTH_LONG).show();

                ActivityCompat.requestPermissions(MainActivity.this, REQUIRED_PERMISSIONS, PERMISSIONS_REQUEST_CODE);
            }
            else{
                //퍼미션 거부 한 적 없는 경우
                ActivityCompat.requestPermissions(MainActivity.this, REQUIRED_PERMISSIONS, PERMISSIONS_REQUEST_CODE);
            }
        }
    }
    private void showDialogForLocationServiceSetting() {

        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("위치 서비스 비활성화");
        builder.setMessage("앱을 사용하기 위해서는 위치 서비스가 필요합니다.\n"
                + "위치 설정을 수정하실래요?");
        builder.setCancelable(true);
        builder.setPositiveButton("설정", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                Intent callGPSSettingIntent
                        = new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivityForResult(callGPSSettingIntent, GPS_ENABLE_REQUEST_CODE);
            }
        });
        builder.setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                dialog.cancel();
            }
        });
        builder.create().show();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        int size = latitude.size();
        double lat;
        double lon;

        switch (requestCode) {
            case GPS_ENABLE_REQUEST_CODE:

                //사용자가 GPS 활성 시켰는지 검사
                if (checkLocationServicesStatus()) {
                    if (checkLocationServicesStatus()) {
                        checkRunTimePermission();
                        return;
                    }
                }
                break;

            case REQ_CODE:
                mapView.setCurrentLocationTrackingMode(MapView.CurrentLocationTrackingMode.TrackingModeOff);
                //현위치 인식 끔, 계속 켜놓으면 현재 위치 반복 설정됨

            switch(resultCode){
                    case RESULT_OK:
                        lat = Double.parseDouble(latitude.get(size - 1));
                        lon = Double.parseDouble(longitude.get(size - 1));

                        Log.d(TAG, "정보 제대로 받아왔음");
                        mapView.setMapCenterPoint(MapPoint.mapPointWithGeoCoord(lat, lon), true); //등록한 주소로 중심점 이동

                        //마커 세우기
                        MapPoint MARKER_POINT = MapPoint.mapPointWithGeoCoord(lat, lon);
                        MapPOIItem marker = new MapPOIItem();
                        marker.setItemName("사용자");
                        marker.setTag(0);
                        marker.setMapPoint(MARKER_POINT);
                        marker.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
                        marker.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.

                        mapView.addPOIItem(marker);

                        break;
//                    case RESULT_CANCELED:
//                        Toast.makeText(this, "사용자 정보 추가 취소", Toast.LENGTH_SHORT).show();
//                        break;
                }
                break;
        }
    }

    public boolean checkLocationServicesStatus() {
        LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);

        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
                || locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
    }

    public void onClick(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.fab:
                Toast.makeText(this, "1번 버튼: 위치 검색" +
                        "\n2번 버튼: 현재위치 기준으로 주변환경 검색" +
                        "\n3번 버튼: 현재위치 추적 및 업데이트", Toast.LENGTH_SHORT).show();
                anim();
                break;
            case R.id.fab1: //아래버튼에서부터 1~3임
                Toast.makeText(this, "현재위치 추적 시작", Toast.LENGTH_SHORT).show();
////                searchDetailFab.setVisibility(View.GONE);
////                mLoaderLayout.setVisibility(View.VISIBLE);
                isTrackingMode = true;
                mapView.setCurrentLocationTrackingMode(MapView.CurrentLocationTrackingMode.TrackingModeOnWithHeading);
                anim();
////                stopTrackingFab.setVisibility(View.VISIBLE);
////                mLoaderLayout.setVisibility(View.GONE);
                break;
            case R.id.fab2:
//                isTrackingMode = false;
//                Toast.makeText(this, "현재위치기준 1km 검색 시작", Toast.LENGTH_SHORT).show();
////                stopTrackingFab.setVisibility(View.GONE);
////                mLoaderLayout.setVisibility(View.VISIBLE);
//                anim();
//                //현재 위치 기준으로 1km 검색
//                mapView.removeAllPOIItems();
//                mapView.removeAllCircles();
//                requestSearchLocal(mCurrentLng, mCurrentLat);
//                mapView.setCurrentLocationTrackingMode(MapView.CurrentLocationTrackingMode.TrackingModeOnWithoutHeading);

                //중간지점 구하기
                double max_x = -1; //다각형의 x좌표 중 가장 큰 값
                double min_x = 1000000000; //다각형의 x좌표 중 가장 작은 값

                double max_y = -1; //다각형의 y좌표 중 가장 큰 값
                double min_y = 1000000000; //다각형의 y좌표 중 가장 작은 값

                //다각형 x좌표 중 가장 큰 값 구하기
                for (int i = 0; i < latitude.size(); i++){
                    lat.add(Double.parseDouble(latitude.get(i)));
                    if (max_x < lat.get(i)){
                        max_x = lat.get(i);
                    }
                }

                //다각형 x좌표 중 가장 작은 값 구하기
                for (int i = 0; i < latitude.size(); i++){
                    if (min_x > lat.get(i)){
                        min_x = lat.get(i);
                    }
                }

                //다각형 y좌표 중 가장 큰 값 구하기
                for (int i = 0; i < longitude.size(); i++){
                    lon.add(Double.parseDouble(longitude.get(i)));
                    if (max_y < lon.get(i)){
                        max_y = lon.get(i);
                    }
                }

                for (int i = 0; i < longitude.size(); i++){
                    if (min_y > lon.get(i)){
                        min_y = lon.get(i);
                    }
                }

                double center_x = min_x + ((max_x - min_x) / 2); //x좌표 중간
                double center_y = min_y + ((max_y - min_y) / 2); //y좌표 중간

                mapView.setCurrentLocationTrackingMode(MapView.CurrentLocationTrackingMode.TrackingModeOff);
                mapView.setMapCenterPoint(MapPoint.mapPointWithGeoCoord(center_x, center_y), true); //등록한 주소로 중심점 이동

//                //원 그리기
//                MapCircle center_circle = new MapCircle(
//                        MapPoint.mapPointWithGeoCoord(center_x, center_y), 300,
//                        Color.argb(128, 255, 0, 0), // strokeColor
//                        Color.argb(128, 255, 255, 0) // fillColor
//                );
//                center_circle.setTag(100);
//                mapView.addCircle(center_circle);

                requestSearchLocal(center_y, center_x);

                Toast.makeText(this, "만날 장소를 선택해주세요.", Toast.LENGTH_LONG).show();

//                mapView.setMapViewEventListener(this);
                mapView.setPOIItemEventListener(this);


                break;

                case R.id.fab3:
                Intent intent = new Intent(this, SearchActivity.class);
//                startActivity(intent);
                startActivityForResult(intent, REQ_CODE);
                break;

        }
    }

    public void anim() {
        if (isFabOpen) {
            fab1.startAnimation(fab_close);
            fab2.startAnimation(fab_close);
            fab3.startAnimation(fab_close);
            fab1.setClickable(false);
            fab2.setClickable(false);
            fab3.setClickable(false);
            isFabOpen = false;
        } else {
            fab1.startAnimation(fab_open);
            fab2.startAnimation(fab_open);
            fab3.startAnimation(fab_open);
            fab1.setClickable(true);
            fab2.setClickable(true);
            fab3.setClickable(true);
            isFabOpen = true;
        }
    }

    @Override
    public void onMapViewInitialized(MapView mapView) {

    }

    @Override
    public void onMapViewCenterPointMoved(MapView mapView, MapPoint mapPoint) {

    }

    @Override
    public void onMapViewZoomLevelChanged(MapView mapView, int i) {

    }

    @Override
    public void onMapViewSingleTapped(MapView mapView, MapPoint mapPoint) {
        //지도 터치 이벤트
//        touch_x = mapPoint.getMapPointGeoCoord().longitude; //터치 부분 위도
//        touch_y = mapPoint.getMapPointGeoCoord().longitude; //터치 부분 경도
//
//        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
//        List<Address> addresses = null;
//        Address address = null;
//
//        try{
//            addresses = geocoder.getFromLocation(touch_x, touch_y, 1);
//
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//
//        if (addresses == null || addresses.size() == 0){
//            //주소 미발견
//        }
//        else{
//            address = addresses.get(0);
//        }
//
//        Toast.makeText(this, String.valueOf(touch_x), Toast.LENGTH_LONG).show();
//        Log.d(TAG, "onMapViewSingleTapped");





    }

    @Override
    public void onMapViewDoubleTapped(MapView mapView, MapPoint mapPoint) {

    }

    @Override
    public void onMapViewLongPressed(MapView mapView, MapPoint mapPoint) {

    }

    @Override
    public void onMapViewDragStarted(MapView mapView, MapPoint mapPoint) {

    }

    @Override
    public void onMapViewDragEnded(MapView mapView, MapPoint mapPoint) {

    }

    @Override
    public void onMapViewMoveFinished(MapView mapView, MapPoint mapPoint) {

    }

    @Override
    public void onDaumMapOpenAPIKeyAuthenticationResult(MapView mapView, int i, String s) {

    }

    @Override
    public void onPOIItemSelected(MapView mapView, MapPOIItem mapPOIItem) {


    }

    @Override
    public void onCalloutBalloonOfPOIItemTouched(MapView mapView, MapPOIItem mapPOIItem) {
//        touch_x = mapPoint.getMapPointGeoCoord().longitude; //터치 부분 위도
//        touch_y = mapPoint.getMapPointGeoCoord().longitude; //터치 부분 경도

        touch_x = mapPOIItem.getMapPoint().getMapPointGeoCoord().latitude;
        touch_y = mapPOIItem.getMapPoint().getMapPointGeoCoord().longitude;

        center_pick = mapPOIItem.getItemName();

        Log.d(TAG, String.valueOf(latitude.size()));
        Log.d(TAG, String.valueOf(longitude.size()));
        Log.d(TAG, String.valueOf(touch_x));
        Log.d(TAG, String.valueOf(touch_y));

        Log.d(TAG, "말풍선 터치");
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("중간 지점 설정")
                .setMessage(center_pick + " 를 중간 지점으로 설정하시겠습니까?")
                .setPositiveButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(MainActivity.this, TimeActivity.class);

                        startActivity(intent);
                    }
                })
                .setNegativeButton("취소", null)
                .setCancelable(false)
                .show();
    }
    
    @Override
    public void onCalloutBalloonOfPOIItemTouched(MapView mapView, MapPOIItem mapPOIItem, MapPOIItem.CalloutBalloonButtonType calloutBalloonButtonType) {

    }

    @Override
    public void onDraggablePOIItemMoved(MapView mapView, MapPOIItem mapPOIItem, MapPoint mapPoint) {

    }

    private void requestSearchLocal(double x, double y) {
        bigMartList.clear();
        gs24List.clear();
        subwayList.clear();
        bankList.clear();
        restaurantList.clear();
        cafeList.clear();

        ApiInterface apiInterface = ApiClient.getApiClient().create(ApiInterface.class);
        Call<CategoryResult> call = apiInterface.getSearchCategory(getString(R.string.restapi_key), "MT1", x + "", y + "", 1000);
        call.enqueue(new Callback<CategoryResult>() {
            @Override
            public void onResponse(@NotNull Call<CategoryResult> call, @NotNull Response<CategoryResult> response) {
                if (response.isSuccessful()) {
                    assert response.body() != null;
                    if (response.body().getDocuments() != null) {
                        Log.d(TAG, "bigMartList Success");
                        bigMartList.addAll(response.body().getDocuments());
                    }
                    call = apiInterface.getSearchCategory(getString(R.string.restapi_key), "CS2", x + "", y + "", 1000);
                    call.enqueue(new Callback<CategoryResult>() {
                        @Override
                        public void onResponse(@NotNull Call<CategoryResult> call, @NotNull Response<CategoryResult> response) {
                            if (response.isSuccessful()) {
                                assert response.body() != null;
                                Log.d(TAG, "gs24List Success");
                                gs24List.addAll(response.body().getDocuments());

                                call = apiInterface.getSearchCategory(getString(R.string.restapi_key), "SW8", x + "", y + "", 1000);
                                call.enqueue(new Callback<CategoryResult>() {
                                    @Override
                                    public void onResponse(@NotNull Call<CategoryResult> call, @NotNull Response<CategoryResult> response) {
                                        if (response.isSuccessful()) {
                                            assert response.body() != null;
                                            Log.d(TAG, "subwayList Success");
                                            subwayList.addAll(response.body().getDocuments());

                                            call = apiInterface.getSearchCategory(getString(R.string.restapi_key), "FD6", x + "", y + "", 1000);
                                            call.enqueue(new Callback<CategoryResult>() {
                                                @Override
                                                public void onResponse(@NotNull Call<CategoryResult> call, @NotNull Response<CategoryResult> response) {
                                                    if (response.isSuccessful()) {
                                                        assert response.body() != null;
                                                        Log.d(TAG, "restaurantList Success");
                                                        restaurantList.addAll(response.body().getDocuments());
                                                        call = apiInterface.getSearchCategory(getString(R.string.restapi_key), "CE7", x + "", y + "", 1000);
                                                        call.enqueue(new Callback<CategoryResult>() {
                                                            @Override
                                                            public void onResponse(@NotNull Call<CategoryResult> call, @NotNull Response<CategoryResult> response) {
                                                                if (response.isSuccessful()) {
                                                                    assert response.body() != null;
                                                                    Log.d(TAG, "cafeList Success");
                                                                    cafeList.addAll(response.body().getDocuments());
                                                                    //모두 통신 성공 시 circle 생성
                                                                    MapCircle circle1 = new MapCircle(
                                                                            MapPoint.mapPointWithGeoCoord(y, x), // center
                                                                            1000, // radius
                                                                            Color.argb(128, 255, 0, 0), // strokeColor
                                                                            Color.argb(128, 0, 255, 0) // fillColor
                                                                    );
                                                                    circle1.setTag(100);
                                                                    mapView.addCircle(circle1);
                                                                    Log.d(TAG, "원 생성");

                                                                    Log.d("SIZE1", bigMartList.size() + "");
                                                                    Log.d("SIZE2", gs24List.size() + "");
                                                                    Log.d("SIZE3", subwayList.size() + "");
                                                                    Log.d("SIZE4", bankList.size() + "");
                                                                    Log.d("SIZE5", restaurantList.size() + "");
                                                                    //마커 생성
                                                                    int tagNum = 10;
                                                                    for (Document document : bigMartList) {
                                                                        MapPOIItem marker = new MapPOIItem();
                                                                        marker.setItemName(document.getPlaceName()); //눌렀을 때 이름 나오게 하는 코드

                                                                        marker.setTag(tagNum++);
                                                                        double x = Double.parseDouble(document.getY());
                                                                        double y = Double.parseDouble(document.getX());
                                                                        //카카오맵은 참고로 new MapPoint()로  생성못함. 좌표기준이 여러개라 이렇게 메소드로 생성해야함
                                                                        MapPoint mapPoint = MapPoint.mapPointWithGeoCoord(x, y);
                                                                        marker.setMapPoint(mapPoint);
//                                                                                                                        marker.setMarkerType(MapPOIItem.MarkerType.CustomImage); // 마커타입을 커스텀 마커로 지정.
//                                                                                                                        marker.setCustomImageResourceId(R.drawable.ic_big_mart_marker); // 마커 이미지.
                                                                        marker.setMarkerType(MapPOIItem.MarkerType.YellowPin);
                                                                        marker.setCustomImageAutoscale(false); // hdpi, xhdpi 등 안드로이드 플랫폼의 스케일을 사용할 경우 지도 라이브러리의 스케일 기능을 꺼줌.
                                                                        marker.setCustomImageAnchor(0.5f, 1.0f); // 마커 이미지중 기준이 되는 위치(앵커포인트) 지정 - 마커 이미지 좌측 상단 기준 x(0.0f ~ 1.0f), y(0.0f ~ 1.0f) 값.
                                                                        mapView.addPOIItem(marker);

                                                                        marker.setShowAnimationType(MapPOIItem.ShowAnimationType.SpringFromGround);
                                                                    }
                                                                    for (Document document : gs24List) {
                                                                        MapPOIItem marker = new MapPOIItem();
                                                                        marker.setItemName(document.getPlaceName());

                                                                        marker.setTag(tagNum++);
                                                                        double x = Double.parseDouble(document.getY());
                                                                        double y = Double.parseDouble(document.getX());
                                                                        //카카오맵은 참고로 new MapPoint()로  생성못함. 좌표기준이 여러개라 이렇게 메소드로 생성해야함
                                                                        MapPoint mapPoint = MapPoint.mapPointWithGeoCoord(x, y);
                                                                        marker.setMapPoint(mapPoint);
//                                                                                                                        marker.setMarkerType(MapPOIItem.MarkerType.CustomImage); // 마커타입을 커스텀 마커로 지정.
//                                                                                                                        marker.setCustomImageResourceId(R.drawable.ic_24_mart_marker); // 마커 이미지.
                                                                        marker.setMarkerType(MapPOIItem.MarkerType.YellowPin);
                                                                        marker.setCustomImageAutoscale(false); // hdpi, xhdpi 등 안드로이드 플랫폼의 스케일을 사용할 경우 지도 라이브러리의 스케일 기능을 꺼줌.
                                                                        marker.setCustomImageAnchor(0.5f, 1.0f);
                                                                        mapView.addPOIItem(marker);

                                                                        marker.setShowAnimationType(MapPOIItem.ShowAnimationType.SpringFromGround);
                                                                    }
                                                                    for (Document document : subwayList) {
                                                                        MapPOIItem marker = new MapPOIItem();
                                                                        marker.setItemName(document.getPlaceName());

                                                                        marker.setTag(tagNum++);
                                                                        double x = Double.parseDouble(document.getY());
                                                                        double y = Double.parseDouble(document.getX());
                                                                        //카카오맵은 참고로 new MapPoint()로  생성못함. 좌표기준이 여러개라 이렇게 메소드로 생성해야함
                                                                        MapPoint mapPoint = MapPoint.mapPointWithGeoCoord(x, y);
                                                                        marker.setMapPoint(mapPoint);
//                                                                                                                        marker.setMarkerType(MapPOIItem.MarkerType.CustomImage); // 마커타입을 커스텀 마커로 지정.
//                                                                                                                        marker.setCustomImageResourceId(R.drawable.ic_subway_marker); // 마커 이미지.
                                                                        marker.setMarkerType(MapPOIItem.MarkerType.YellowPin);

                                                                        marker.setCustomImageAutoscale(false); // hdpi, xhdpi 등 안드로이드 플랫폼의 스케일을 사용할 경우 지도 라이브러리의 스케일 기능을 꺼줌.
                                                                        marker.setCustomImageAnchor(0.5f, 1.0f);
                                                                        mapView.addPOIItem(marker);

                                                                        marker.setShowAnimationType(MapPOIItem.ShowAnimationType.SpringFromGround);
                                                                    }
                                                                    for (Document document : bankList) {
                                                                        MapPOIItem marker = new MapPOIItem();
                                                                        marker.setItemName(document.getPlaceName());

                                                                        marker.setTag(tagNum++);
                                                                        double x = Double.parseDouble(document.getY());
                                                                        double y = Double.parseDouble(document.getX());
                                                                        //카카오맵은 참고로 new MapPoint()로  생성못함. 좌표기준이 여러개라 이렇게 메소드로 생성해야함
                                                                        MapPoint mapPoint = MapPoint.mapPointWithGeoCoord(x, y);
                                                                        marker.setMapPoint(mapPoint);
//                                                                                                                        marker.setMarkerType(MapPOIItem.MarkerType.CustomImage); // 마커타입을 커스텀 마커로 지정.
//                                                                                                                        marker.setCustomImageResourceId(R.drawable.ic_bank_marker); // 마커 이미지.
                                                                        marker.setMarkerType(MapPOIItem.MarkerType.YellowPin);

                                                                        marker.setCustomImageAutoscale(false); // hdpi, xhdpi 등 안드로이드 플랫폼의 스케일을 사용할 경우 지도 라이브러리의 스케일 기능을 꺼줌.
                                                                        marker.setCustomImageAnchor(0.5f, 1.0f);
                                                                        mapView.addPOIItem(marker);

                                                                        marker.setShowAnimationType(MapPOIItem.ShowAnimationType.SpringFromGround);
                                                                    }
                                                                    for (Document document : restaurantList) {
                                                                        MapPOIItem marker = new MapPOIItem();
                                                                        marker.setItemName(document.getPlaceName());

                                                                        marker.setTag(tagNum++);
                                                                        double x = Double.parseDouble(document.getY());
                                                                        double y = Double.parseDouble(document.getX());
                                                                        //카카오맵은 참고로 new MapPoint()로  생성못함. 좌표기준이 여러개라 이렇게 메소드로 생성해야함
                                                                        MapPoint mapPoint = MapPoint.mapPointWithGeoCoord(x, y);
                                                                        marker.setMapPoint(mapPoint);
//                                                                                                                        marker.setMarkerType(MapPOIItem.MarkerType.CustomImage); // 마커타입을 커스텀 마커로 지정.
//                                                                                                                        marker.setCustomImageResourceId(R.drawable.ic_pharmacy_marker); // 마커 이미지.
                                                                        marker.setMarkerType(MapPOIItem.MarkerType.YellowPin);

                                                                        marker.setCustomImageAutoscale(false); // hdpi, xhdpi 등 안드로이드 플랫폼의 스케일을 사용할 경우 지도 라이브러리의 스케일 기능을 꺼줌.
                                                                        marker.setCustomImageAnchor(0.5f, 1.0f);
                                                                        mapView.addPOIItem(marker);

                                                                        marker.setShowAnimationType(MapPOIItem.ShowAnimationType.SpringFromGround);
                                                                        //자세히보기 fab 버튼 보이게
//                                                                                                                        mLoaderLayout.setVisibility(View.GONE);
//                                                                                                                        searchDetailFab.setVisibility(View.VISIBLE);
                                                                    }
                                                                    for (Document document : cafeList) {
                                                                        MapPOIItem marker = new MapPOIItem();
                                                                        marker.setItemName(document.getPlaceName());

                                                                        marker.setTag(tagNum++);
                                                                        double x = Double.parseDouble(document.getY());
                                                                        double y = Double.parseDouble(document.getX());
                                                                        //카카오맵은 참고로 new MapPoint()로  생성못함. 좌표기준이 여러개라 이렇게 메소드로 생성해야함
                                                                        MapPoint mapPoint = MapPoint.mapPointWithGeoCoord(x, y);
                                                                        marker.setMapPoint(mapPoint);
//                                                                                                                        marker.setMarkerType(MapPOIItem.MarkerType.CustomImage); // 마커타입을 커스텀 마커로 지정.
//                                                                                                                        marker.setCustomImageResourceId(R.drawable.ic_cafe_marker); // 마커 이미지.
                                                                        marker.setMarkerType(MapPOIItem.MarkerType.YellowPin);

                                                                        marker.setCustomImageAutoscale(false); // hdpi, xhdpi 등 안드로이드 플랫폼의 스케일을 사용할 경우 지도 라이브러리의 스케일 기능을 꺼줌.
                                                                        marker.setCustomImageAnchor(0.5f, 1.0f);
                                                                        mapView.addPOIItem(marker);

                                                                        marker.setShowAnimationType(MapPOIItem.ShowAnimationType.SpringFromGround);

                                                                    }

                                                                }

                                                            }

                                                            @Override
                                                            public void onFailure(@NotNull Call<CategoryResult> call, @NotNull Throwable t) {

                                                            }
                                                        });
                                                    }
                                                }

                                                @Override
                                                public void onFailure(@NotNull Call<CategoryResult> call, Throwable t) {

                                                }
                                            });
                                        }
                                    }

                                    @Override
                                    public void onFailure(@NotNull Call<CategoryResult> call, @NotNull Throwable t) {

                                    }
                                });
                            }
                        }

                        @Override
                        public void onFailure(@NotNull Call<CategoryResult> call, @NotNull Throwable t) {

                        }
                    });
                }
            }

            @Override
            public void onFailure(@NotNull Call<CategoryResult> call, @NotNull Throwable t) {

            }
        });
    }
}