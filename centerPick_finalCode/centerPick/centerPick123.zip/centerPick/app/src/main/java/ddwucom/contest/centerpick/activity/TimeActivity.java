package ddwucom.contest.centerpick.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.TextView;

import com.odsay.odsayandroidsdk.API;
import com.odsay.odsayandroidsdk.ODsayData;
import com.odsay.odsayandroidsdk.ODsayService;
import com.odsay.odsayandroidsdk.OnResultCallbackListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import ddwucom.contest.centerpick.R;
import ddwucom.contest.centerpick.adapter.TimeAdapter;
import ddwucom.contest.centerpick.data.TimeData;
import ddwucom.contest.centerpick.data.TimeDataManager;

import static ddwucom.contest.centerpick.activity.MainActivity.latitude;
import static ddwucom.contest.centerpick.activity.MainActivity.longitude;
import static ddwucom.contest.centerpick.activity.MainActivity.touch_x;
import static ddwucom.contest.centerpick.activity.MainActivity.touch_y;

public class TimeActivity extends AppCompatActivity {

    private ODsayService odsayService;
    final static String TAG = "ABC";
    //테스트용
    private TextView tv_data;
    public static ArrayList<Integer> time = new ArrayList<>(); //사람들의 최솟값
    private ListView listView;
    private TimeAdapter timeAdapter;
    private ArrayList<TimeData> timeList;
    static int min = 100000;
    TimeDataManager manager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time);

        // 싱글톤 생성, Key 값을 활용하여 객체 생성
        odsayService = ODsayService.init(this, "UQpy5z5jYlkG7opjycDDO26k1WqH5NwUshX6iB5fir8");
        // 서버 연결 제한 시간(단위(초), default : 5초)
        odsayService.setReadTimeout(5000);
        // 데이터 획득 제한 시간(단위(초), default : 5초)
        odsayService.setConnectionTimeout(5000);

        OnResultCallbackListener onResultCallbackListener = new OnResultCallbackListener() {

            @Override
            public void onSuccess(ODsayData odsayData, API api) {
                try {
                    if (api == API.SEARCH_PUB_TRANS_PATH) {
                        doJSONParser(odsayData);
                        Log.d(TAG, "중간과정1 최소시간: " + min);

                        time.add(min);

//                    listView = findViewById(R.id.listView);
//
//                    manager = new TimeDataManager();
//                    timeList = manager.getTimeDataList();
//                    timeAdapter = new TimeAdapter(TimeActivity.this, R.layout.time_list, timeList);
//                    listView.setAdapter(timeAdapter);
                    }
                }catch (JSONException e){
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(int i, String errorMessage, API api) {
                //에러 발생
                if (api == API.SEARCH_PUB_TRANS_PATH)
                    tv_data.setText("API : " + api.name() + "\n" + errorMessage);
            }
        };

        String x = String.valueOf(touch_x);
        String y = String.valueOf(touch_y);

        Log.d(TAG, String.valueOf(time.size()));

        for (int i = 0; i < latitude.size(); i++){
            min = 100000;
            odsayService.requestSearchPubTransPath(longitude.get(i), latitude.get(i), y, x, "0", "0", "0", onResultCallbackListener);

            Log.d(TAG, String.valueOf(time.size()));

        }

        Log.d(TAG, String.valueOf(time.size()));

        for (int i = 0; i < time.size(); i++){
            Log.d(TAG, "뀨...." + time.get(i).toString());
        }



//        listView = findViewById(R.id.listView);
//
//        manager = new TimeDataManager();
//        timeList = manager.getTimeDataList();
//        timeAdapter = new TimeAdapter(this, R.layout.time_list, timeList);
//        listView.setAdapter(timeAdapter);
    }


    public void doJSONParser(ODsayData odsayData) throws JSONException{
        ArrayList<Integer> times = new ArrayList<>(); //한 사람이 걸리는 시간의 경우들

//        min = 100000;
        times.clear();
        Log.d(TAG, String.valueOf(time.size()));

        JSONObject result = odsayData.getJson().getJSONObject("result");

        JSONArray path = (JSONArray)result.get("path");

        for (int i = 0; i < path.length(); i++){
            JSONObject j = path.getJSONObject(i);

//            String pathType = j.getString("pathType");
            JSONObject info = j.getJSONObject("info");

            String totalTime = info.getString("totalTime");
            int t = Integer.parseInt(totalTime);
            times.add(t);


        }
        for (int k = 0; k < times.size(); k++){
            if (min > times.get(k)){
                min = times.get(k);
            }
        }

        Log.d(TAG, "최소시간: " + min);




//        StringBuffer sb = new StringBuffer();
//
//        JSONObject result = odsayData.getJson().getJSONObject("result");
//
//        JSONArray path = (JSONArray)result.get("path");
//
//        for (int i = 0; i < path.length(); i++){
//            JSONObject j = path.getJSONObject(i);
//
//            String pathType = j.getString("pathType");
//
//            JSONObject info = j.getJSONObject("info");
//
//            String totalTime = info.getString("totalTime");
//
//            sb.append("결과 종류" + pathType + "\n" +
//                    "소요 시간" + totalTime + "\n\n");
//        }


    }
}